package main;

/**
 * Created by Lukasz on 2014-12-11.
 */
public class Packet {
    public String tag;
    public Object object;
}
