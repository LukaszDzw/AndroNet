package interfaces;

import main.Connection;

/**
 * Created by Lukasz on 2015-01-02.
 */
public interface IDisconnected {
    public void disconnected(Connection connection);
}
