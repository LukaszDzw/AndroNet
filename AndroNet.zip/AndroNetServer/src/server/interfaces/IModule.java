package server.interfaces;

import main.Server;

/**
 * Created by Lukasz on 2015-01-03.
 */
public interface IModule {
    public void setup(Server server);
}
