package pl.umk.andronetandroidclient.network.packets;

/**
 * Created by Lukasz on 2015-01-04.
 */
public class ChatUser {
    public int id;
    public String name;
}
