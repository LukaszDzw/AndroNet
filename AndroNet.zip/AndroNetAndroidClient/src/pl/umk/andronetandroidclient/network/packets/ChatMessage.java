package pl.umk.andronetandroidclient.network.packets;

/**
 * Created by Lukasz on 2015-01-03.
 */
public class ChatMessage {
    public int id;
    public String message;
    public String time;
}
