package pl.umk.andronetandroidclient.network.packets;

import pl.umk.andronetandroidclient.network.enums.Rgb;

/**
 * Created by Lukasz on 2015-01-06.
 */
public class ChangedRgbColor {
    public int channel;
    public Rgb type;
    public int value;
}


