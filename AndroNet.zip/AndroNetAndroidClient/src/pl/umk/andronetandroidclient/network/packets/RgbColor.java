package pl.umk.andronetandroidclient.network.packets;

/**
 * Created by Lukasz on 2015-01-06.
 */
public class RgbColor {
    public int r, g, b;
}
