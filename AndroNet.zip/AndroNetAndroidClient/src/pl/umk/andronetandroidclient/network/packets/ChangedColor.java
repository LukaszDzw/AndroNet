package pl.umk.andronetandroidclient.network.packets;

import pl.umk.andronetandroidclient.network.enums.Color;

/**
 * Created by Lukasz on 2015-01-05.
 */
public class ChangedColor {
    public int id;
    public Color color;
}
