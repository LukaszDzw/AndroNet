package pl.umk.andronetandroidclient.network.packets;

/**
 * Created by Lukasz on 2015-01-05.
 */
public class DrawUser {
    public int id;
    public String color;
}
