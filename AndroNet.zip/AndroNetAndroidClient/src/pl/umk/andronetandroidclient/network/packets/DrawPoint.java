package pl.umk.andronetandroidclient.network.packets;

import pl.umk.andronetandroidclient.network.enums.Action;

/**
 * Created by Lukasz on 2014-12-29.
 */
public class DrawPoint {
    public int id;
    public Action action;
    public float x;
    public float y;
}