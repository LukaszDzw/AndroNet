package pl.umk.andronetandroidclient.network.enums;

/**
 * Created by Lukasz on 2014-12-29.
 */
public enum Action {
    ACTION_DOWN,
    ACTION_MOVE,
    ACTION_UP
}
