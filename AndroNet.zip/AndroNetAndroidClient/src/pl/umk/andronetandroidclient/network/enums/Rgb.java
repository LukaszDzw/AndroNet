package pl.umk.andronetandroidclient.network.enums;

/**
 * Created by Lukasz on 2015-01-06.
 */
public enum Rgb {
    RED,
    GREEN,
    BLUE
}
