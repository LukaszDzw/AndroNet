package pl.umk.andronetandroidclient.network.enums;

/**
 * Created by Lukasz on 2014-12-30.
 */
public enum Tags {
    chatMessage,
    registerChat,
    getChatUser,
    disconnected,
    drawPosition,
    getDrawerUser,
    drawChangeColor,
    hello,
    getColor,
    changeColor
}
