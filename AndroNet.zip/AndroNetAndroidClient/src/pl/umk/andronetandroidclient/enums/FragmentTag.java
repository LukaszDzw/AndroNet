package pl.umk.andronetandroidclient.enums;

/**
 * Created by Lukasz on 2015-01-07.
 */
public enum FragmentTag {
    Chat,
    ChatName,
    Colors,
    Drawer
}
