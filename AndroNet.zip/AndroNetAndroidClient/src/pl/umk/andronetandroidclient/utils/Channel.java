package pl.umk.andronetandroidclient.utils;

/**
 * Created by Lukasz on 2015-01-07.
 */
public class Channel {

    private int mKey;

    public int getmKey() {
        return mKey;
    }

    public void setmKey(int mKey) {
        this.mKey = mKey;
    }
}
